=== WP-VGWORT ===
Contributors: smoo1337
Donate link: http://mywebcheck.de/
Tags: VG-Wort, VGW, Zählpixel
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP_VGWORT add the "VG Wort Zaehlpixel" to your posts/pages.

== Description ==

VG Wort Plugin ist ein Plugin mit den man die VG Wort Zählmarken schnell in einen Beitrag einfügen kann.

Folgende Funktionen bietet das Plugin

- Zählung der Zeichen inkl. Leerzeichen im Beitrag
- (Besonderheit) Shortcodes, Bilder und HTML Elemente werden nicht eingerechnet
- Einfügen einer VG Wort Zählmarke im Beitrag
- Kompatibel mit anderen VG WORT Plugins, durch Konfigurationsmöglichkeiten
- Übersicht in der Beitragsübersicht ob VG Wort Zählmarken eingebunden sind
- Übersicht im Profil in welchen Beiträgen VG Wort Zählmarken noch fehlen, welche die Bedingungen von VG Wort erfüllen

== Installation ==

* Entpacke das Archiv ins Wordpress Plugin Verzeichnis (wp-content/plugins/)
* Aktiviere das Plugin im Wordpress Backend.
* Fertig, nun befindet sich in Beiträgen und Seiten die Eingabemaske 

== Frequently Asked Questions ==

Diskussion unter http://mywebcheck.de

== Screenshots ==

- no screenshots available

== Changelog ==

= 1.0 =
* start of Plugin